<?php

namespace App\Contracts;

interface ProductSerialNumberRepository extends BaseRepository
{
}
