<?php

namespace App\Contracts;

interface ProductRepository extends BaseRepository
{
}
