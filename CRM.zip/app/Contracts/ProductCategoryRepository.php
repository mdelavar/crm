<?php

namespace App\Contracts;

interface ProductCategoryRepository extends BaseRepository
{
}
