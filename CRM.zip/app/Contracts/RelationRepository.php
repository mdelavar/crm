<?php

namespace App\Contracts;

interface RelationRepository extends BaseRepository
{
}
