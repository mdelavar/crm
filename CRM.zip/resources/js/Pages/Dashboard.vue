<script setup>
import {Head} from '@inertiajs/vue3';
import DashboardLayout from "@/Layouts/DashboardLayout.vue";
</script>

<template>
    <Head title="داشبورد"/>
    <DashboardLayout route-name="dashboard">

    </DashboardLayout>
</template>
