<template>
    <button
        class="text-sm flex items-center px-3 py-2 bg-themeDarkPrimary border border-transparent rounded-md text-center text-white hover:bg-themeLightPrimary focus:bg-themePrimary active:bg-themePrimary focus:outline-none focus:ring-2 focus:ring-themePrimary focus:ring-offset-2 transition ease-in-out duration-150"
    >
        <slot />
    </button>
</template>
