<template>
    <div class="p-6">
        <CreditList v-if="currentPage=== 'list'" @entry-page="clearForm" @edit-item="edit"></CreditList>
        <CreditEntry v-if="currentPage=== 'entry'" @back-page="currentPage = 'list'" :credit="edit_item"></CreditEntry>
    </div>
</template>
<script>
import {Head} from "@inertiajs/vue3";
import {defineComponent} from "vue";
import {Link} from "@inertiajs/vue3";
import PrimaryButton from "@/Components/PrimaryButton.vue";
import CreditList from "./list.vue";
import CreditEntry from "./entry.vue";

export default defineComponent({
    components: {PrimaryButton, Head, Link, CreditList, CreditEntry},
    data() {
        return {
            currentPage: "list",
            edit_item: null,
        }
    },
    created() {
    },
    methods: {
        edit(item) {
            this.edit_item = item;
            this.currentPage = "entry";
        },
        clearForm() {
            this.edit_item = null;
            this.currentPage = 'entry';
        },
    }
});
</script>
