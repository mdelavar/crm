<?php

namespace App\Contracts;

interface RelationCategoryRepository extends BaseRepository
{
}
