<?php

namespace App\Contracts;

interface OrganizationRepository extends BaseRepository
{
}
