<?php

namespace App\Contracts;

interface OrganizationPeopleRepository extends BaseRepository
{
}
