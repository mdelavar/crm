<?php

namespace App\Contracts;

interface CarServiceRepository extends BaseRepository
{
}
