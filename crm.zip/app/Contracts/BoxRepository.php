<?php

namespace App\Contracts;

interface BoxRepository extends BaseRepository
{
}
