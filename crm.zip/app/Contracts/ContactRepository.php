<?php

namespace App\Contracts;

interface ContactRepository extends BaseRepository
{
}
