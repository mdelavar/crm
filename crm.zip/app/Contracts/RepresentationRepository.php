<?php

namespace App\Contracts;

interface RepresentationRepository extends BaseRepository
{
}
