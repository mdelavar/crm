<?php

namespace App\Contracts;


use Illuminate\Contracts\Pagination\LengthAwarePaginator;

interface ServicesRepository extends BaseRepository
{
}
